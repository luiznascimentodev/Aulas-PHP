<footer class="footer mt-5 py-3 bg-light rounded">
  <div class="container text-center">
    <p class="text-white mb-0">&copy; <?php echo date('Y'); ?> Sistema de Gerenciamento de Tarefas. Todos os direitos reservados.</p>
  </div>
</footer>

</html>